

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-0@2u)g%@ywagrci&(f7rg1)@20&97nm_=--t-6ufq#y06sku5k'